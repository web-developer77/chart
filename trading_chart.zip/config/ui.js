const pairs = ['EUR/SGD', 'USD/EUR'];
const chartTypes = ['Mountain', 'Line', 'Candle'];

export default {
  pairs: pairs.map(p => ({pair: p, label: p})),
  chartTypes: chartTypes.map(t => ({type: t.toLowerCase(), label: t}))
};
